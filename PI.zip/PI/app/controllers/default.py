from flask import render_template, request, url_for, redirect, Flask
from app import app, db


from app.models.tables import Pessoa
from app.models.tables import Contato
from app.models.tables import Tcontato
from app.models.tables import Associado
from app.models.tables import Estabelecimento
from app.models.tables import Cidade
from app.models.tables import Bairro
from app.models.tables import Endereco





@app.route("/home")
def index():
	return render_template('index.html')


@app.route("/cadastrofb", methods=['POST'])
def cadastro():
	if request.method == "POST":
		nome = request.form.get("name")
		email = request.form.get("email")
		id_fb = request.form.get("id")

		pessoa = Pessoa.query.filter_by(codigo_usuario=id_fb).first()
		if pessoa == None:
			if nome  and email and id_fb:
				p = Pessoa(id_fb,nome,email)

				db.session.add(p)
				db.session.commit() 

	return "algo"

@app.route("/est")
def est():
	return render_template('cadastro_estabelecimento.html')
	
@app.route("/logout", methods=['GET'])
def logout():
	return "delogou"


@app.route("/cadastroestabelecimento", methods=['GET', 'POST'])
def estabelecimento():
	if request.method == "POST":
		nome_est = request.form.get("nome")
		logradouro = request.form.get("logradouro")
		cidade = request.form.get("cidade")
		cep = request.form.get("cep")
		numero = request.form.get("numero")
		nome_bairro = request.form.get("bairro")
		pagina = "null"
		nota = "null"
		cnpj = request.form.get("cnpj")
		codigo_usuario = request.form.get("id")
		dsc_contato = request.form.get("telefone")

		print(dsc_contato, nome_est, nome_bairro, codigo_usuario)
		if dsc_contato and cep and cnpj and codigo_usuario and nome_est and logradouro and cidade and numero and nome_bairro  and pagina and nota:

			est = Estabelecimento(cnpj,nome_est,pagina,nota,numero,codigo_usuario)
			end = Endereco(cep,logradouro)
			cid = Cidade(cidade)
			bairro = Bairro(nome_bairro)
			cont = Contato(dsc_contato)

			db.session.add(est)
			db.session.add(end)
			db.session.add(cid)
			db.session.add(bairro)
			db.session.add(cont)

			db.session.commit()

	return redirect(url_for('index'))

def login():
	email = request.form.get("email")
	
	#if request.method == "POST":	
	pessoa = Pessoa.query.filter_by(cod_cidade).first()
		#pessoa = Pessoa.query.filter_by(email=request.form.get("email")).first()


	return(cidade.id)





if __name__ == '__main__':
		app.run(debug=True)





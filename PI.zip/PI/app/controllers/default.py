from flask import render_template, request, url_for, redirect, Flask
from app import app, db


from app.models.tables import Pessoa
from app.models.tables import Contato
from app.models.tables import Tcontato
from app.models.tables import Associado
from app.models.tables import Estabelecimento
from app.models.tables import Cidade
from app.models.tables import Bairro
from app.models.tables import Endereco
from app.models.tables import Cardapio
from app.models.tables import Prato
from app.models.tables import Evento




@app.route("/home")
def index():
	return render_template('index.html')

@app.route("/cadastrar")
def cadastrar():
		return render_template('cadastro_associado.html')
@app.route("/logar")
def logar():
		return render_template('lista.html')

@app.route("/cadastro", methods=['GET', 'POST'])
def cadastro():
	if request.method == "POST":
		nome = request.form.get("nome")
		sexo = request.form.get("sexo")
		email = request.form.get("email")
		senha = request.form.get("senha")
		dsc_contato = request.form.get("fone")
		cnpj = request.form.get("cnpj")

		if nome and sexo and email and senha and dsc_contato and cnpj :
			p = Pessoa(nome,email,senha,sexo)
			cont = Contato(dsc_contato)
			a = Associado(cnpj)


			db.session.add(p)
			db.session.add(cont)
			db.session.add(a)

			

			db.session.commit()

	return redirect(url_for('index'))


@app.route('/login', methods=['GET', 'POST'])
def login():
	email = request.form.get("email")
	
	#if request.method == "POST":	
	pessoa = Pessoa.query.filter_by(email= email).first()
		#pessoa = Pessoa.query.filter_by(email=request.form.get("email")).first()


	return (pessoa.nome)





if __name__ == '__main__':
		app.run(debug=True)

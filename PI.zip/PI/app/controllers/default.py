from flask import render_template, request, url_for, redirect, Flask
from app import app, db


from app.models.tables import Pessoa
from app.models.tables import Contato
from app.models.tables import Tcontato
from app.models.tables import Associado
from app.models.tables import Estabelecimento
from app.models.tables import Cidade
from app.models.tables import Bairro
from app.models.tables import Endereco
from app.models.tables import Cardapio
from app.models.tables import Prato
from app.models.tables import Evento




@app.route("/home")
def index():
	return render_template('index.html')

@app.route("/cadastrar")
def cadastrar():
		return render_template('cadastro_associado.html')

@app.route("/cadastro", methods=['GET', 'POST'])
def cadastro():
	if request.method == "POST":
		nome = request.form.get("nome")
		sexo = request.form.get("sexo")
		dsc_contato = request.form.get("email")
		senha = request.form.get("senha")
		cnpj = request.form.get("cnpj")
		tipo = "Associado"

		if nome and sexo and dsc_contato and senha and cnpj and tipo :
			cont = Contato(dsc_contato,tipo)
			a = Associado(nome,cnpj,senha,sexo)

			db.session.add(cont)
			db.session.add(a)

			

			db.session.commit()

	return redirect(url_for('index'))

@app.route("/est")
def est():
	return render_template('cadastro_estabelecimento.html')
	


@app.route("/cadastroestabelecimento", methods=['GET', 'POST'])
def estabelecimento():
	if request.method == "POST":
		nome_est = request.form.get("nome")
		logradouro = request.form.get("logradouro")
		cidade = request.form.get("cidade")
		cep = request.form.get("cep")
		print(cep)
		numero = request.form.get("numero")
		nome_bairro = request.form.get("bairro")
		dsc_contato = request.form.get("telefone")
		pagina = "null"
		nota = 10
		tipo = "Estabelecimento"
		print(dsc_contato)
		if nome_est and logradouro and cidade and cep and numero and nome_bairro and dsc_contato and pagina and nota and tipo:

			est = Estabelecimento(nome_est,pagina,nota,numero,cep)
			end = Endereco(cep,logradouro)
			cid = Cidade(cidade)
			bairro = Bairro(nome_bairro)
			cont = Contato(dsc_contato, tipo)

			db.session.add(est)
			db.session.add(end)
			db.session.add(cid)
			db.session.add(bairro)
			db.session.add(cont)

			db.session.commit()

	return redirect(url_for('index'))

def login():
	email = request.form.get("email")
	
	#if request.method == "POST":	
	pessoa = Pessoa.query.filter_by(cod_cidade).first()
		#pessoa = Pessoa.query.filter_by(email=request.form.get("email")).first()


	return(cidade.id)





if __name__ == '__main__':
		app.run(debug=True)





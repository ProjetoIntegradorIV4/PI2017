from app import Manager,db

class Pessoa(db.Model):
	__tablename__ = "pessoas"
	codigo_usuario = db.Column(db.Integer, primary_key = True, autoincrement=True)



class Associado(db.Model):
	__tablename__ = "associados"


	id_associado = db.Column(db.Integer, primary_key = True, autoincrement=True)
	nome = db.Column(db.String)
	cnpj = db.Column(db.String)
	senha = db.Column(db.String)
	sexo = db.Column(db.String)
	cod_usuario = db.Column(db.Integer, db.ForeignKey('pessoas.codigo_usuario'))
	cod_contato = db.Column(db.Integer, db.ForeignKey('contatos.cod_contato'))
	

	def __init__(self, nome, cnpj, sexo, senha):
		self.nome = nome
		self.cnpj = cnpj
		self.senha = senha
		self.sexo = sexo

	def __repr__(self):
		return "<Associado %r>" % self.nome

	

class Estabelecimento(db.Model):
	__tablename__ = "estabelecimentos"

	id_est = db.Column(db.Integer, primary_key = True, autoincrement=True)
	nome_est = db.Column(db.String)
	pagina = db.Column(db.String)
	nota = db.Column(db.String)
	numero = db.Column(db.String)
	associado = db.Column(db.Integer, db.ForeignKey('associados.id_associado'))
	cep = db.Column(db.Integer, db.ForeignKey('enderecos.cep'))
	def __init__(self, nome_est, nota, pagina, numero,cep):
		self.nome_est = nome_est
		self.nota = nota 
		self.pagina = pagina
		self.numero = numero
		self.cep = cep


	def __repr__(self):
		return "<Estabelecimento %r>" % self.nome_est

class Ranking(db.Model):
	__tablename__ = "rankings"
	id_ranking = db.Column(db.Integer, primary_key = True, autoincrement=True)
	descricao = db.Column(db.String)
	id_estabelecimento = db.Column(db.Integer, db.ForeignKey('estabelecimentos.id_est'))

	def __init__(self, descricao):
		self.descricao = descricao

	def __repr__(self):
		return "<ranking %r>" % self.descricao

class  Categoria(db.Model):
	__tablename__ = "categorias"
	id_categoria = db.Column(db.Integer, primary_key = True, autoincrement=True)
	descricao = db.Column(db.String)
	nome = db.Column(db.String)
	id_estabelecimento = db.Column(db.Integer, db.ForeignKey('estabelecimentos.id_est'))
	id_tipoestabelecimento = db.Column(db.Integer, db.ForeignKey('tipoestabelecimentos.id_tipoestab'))

	def __init__(self, descricao, nome):
		self.descricao = descricao
		self.nome = nome

	def __repr__(self):
		return "<Ranking %r>" % self.descricao

class Tipoestabelecimento(db.Model):
	__tablename__ = "tipoestabelecimentos"
	id_tipoestab = db.Column(db.Integer, primary_key = True, autoincrement=True)
	descricao = db.Column(db.String)
	nome = db.Column(db.String)
	
	def __init__(self, descricao, nome):
		self.descricao = descricao	

	def __repr__(self):
		return "<Ranking %r>" % self.descricao


class Tcontato(db.Model):
	__tablename__= "tcontatos"

	cod_tcontato = db.Column(db.Integer, primary_key = True, autoincrement=True)
	dsc_tcontato = db.Column(db.String)
	
	def __init__(self, dsc_tcontato):
		self.dsc_tcontato = dsc_tcontato
		
	def __repr__(self):
		return "<Tcontato %r>" % self.dsc_tcontato




class Contato(db.Model):
	__tablename__ = "contatos"
	cod_contato = db.Column(db.Integer, primary_key = True, autoincrement=True)
	dsc_contato = db.Column(db.String)
	tipo = db.Column(db.String)
	id_estabelecimento = db.Column(db.Integer, db.ForeignKey('estabelecimentos.id_est'))
	cod_tcont = db.Column(db.Integer, db.ForeignKey('tcontatos.cod_tcontato'))
	
	def __init__(self, dsc_contato, tipo):
		self.dsc_contato = dsc_contato
		self.tipo = tipo

	def __repr__(self):
		return "<Contato %r>" % self.dsc_contato


class Cidade(db.Model):
	__tablename__ = "cidades"

	cod_cidade = db.Column(db.Integer, primary_key = True, autoincrement=True)
	cidade = db.Column(db.String)
		
	def __init__(self, cidade):
		self.cidade = cidade


	def __repr__(self):
		return "<Cidade %r>" % self.cidade


class Bairro(db.Model):
	__tablename__ = "bairros"

	cod_bairro = db.Column(db.Integer, primary_key = True, autoincrement=True)
	nome_bairro = db.Column(db.String)
	cod_cidade = db.Column(db.Integer, db.ForeignKey('cidades.cod_cidade'))
	
	def __init__(self, nome_bairro):
		self.nome_bairro = nome_bairro

	def __repr__(self):
		return "<Bairro %r>" % self.nome_bairro



class Endereco(db.Model):
	__tablename__ = "enderecos"

	cep = db.Column(db.Integer,  primary_key = True)
	logradouro = db.Column(db.String)
	id_bairro = db.Column(db.Integer, db.ForeignKey('bairros.cod_bairro'))

	def __init__(self, cep, logradouro):
		self.cep = cep
		self.logradouro = logradouro

		
	def __repr__(self):
		return "<Endereco %r>" % self.logradouro




class Cardapio(db.Model):
	__tablename__ = "cardapios"

	cod_cardapio = db.Column(db.Integer, primary_key = True)
	tipo = db.Column(db.String)
	id_est = db.Column(db.Integer, db.ForeignKey('estabelecimentos.id_est'))

	def __init__(self, tipo):
		self.tipo = tipo


	def __repr__(self):
		return "<Cardapio %r>" % self.tipo


class Prato(db.Model):
	__tablename__ = "pratos"

	id_prato = db.Column(db.Integer, primary_key = True)
	tipo = db.Column(db.String)
	nome_prato = db.Column(db.String)
	valor = db.Column(db.Float)
	id_cardapio = db.Column(db.Integer, db.ForeignKey('cardapios.cod_cardapio'))
	
	def __init__(self, tipo,nome_prato, valor):
		self.tipo = tipo
		self.nome = nome_prato
		self.valor = valor

	def __repr__(self):
		return "<Prato %r>" % self.nome_prato, self.valor




class Evento(db.Model):
	__tablename__ = "eventos"
	cod_evento= db.Column(db.Integer, primary_key = True)
	data = db.Column(db.DATETIME)
	horario = db.Column(db.String)
	id_estabelecimento= db.Column(db.Integer, db.ForeignKey('estabelecimentos.id_est'))
	
		
	def __init__(self, data, horario):
		self.data = data
		self.horario = horario


	def __repr__(self):
			return "<Evento %r>" % self.data, self.horario


db.create_all()
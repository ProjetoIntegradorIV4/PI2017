from app import Manager,db
from sqlalchemy.orm import relationship

class Pessoa(db.Model):
	__tablename__ = "pessoas"
	codigo_usuario = db.Column(db.Integer, primary_key = True, unique=True)
	nome = db.Column(db.String)
	email = db.Column(db.String)

	def __init__(self,codigo_usuario, nome,email):
		self.codigo_usuario = codigo_usuario
		self.nome = nome
		self.email = email

	def __repr__(self):
		return "<Pessoa %r>" % self.nome

class Associado(db.Model):
	__tablename__ = "associados"

	id_associado = db.Column(db.Integer, primary_key = True, autoincrement=True)



	def __repr__(self):
		return "<Associado %r>" % self.id_associado

	
class Estabelecimento(db.Model):
	__tablename__ = "estabelecimentos"

	cnpj = db.Column(db.Integer, primary_key = True, unique=True)
	nome_est = db.Column(db.String, unique=True)
	pagina = db.Column(db.String)
	nota = db.Column(db.String)
	numero = db.Column(db.String)
	codigo_usuario = db.Column(db.Integer, db.ForeignKey('pessoas.codigo_usuario'))


	def __init__(self, cnpj, nome_est, nota, pagina, numero,codigo_usuario):
		self.cnpj = cnpj
		self.nome_est = nome_est
		self.nota = nota 
		self.pagina = pagina
		self.numero = numero
		self.codigo_usuario = codigo_usuario

	def __repr__(self):
		return "<Estabelecimento %r>" % self.nome_est

class Ranking(db.Model):
	__tablename__ = "rankings"
	id_ranking = db.Column(db.Integer, primary_key = True, autoincrement=True)
	descricao = db.Column(db.String)

	def __init__(self, descricao):
		self.descricao = descricao

	def __repr__(self):
		return "<Ranking %r>" % self.descricao

class  Categoria(db.Model):
	__tablename__ = "categorias"
	id_categoria = db.Column(db.Integer, primary_key = True, autoincrement=True)
	descricao = db.Column(db.String(40))
	nome = db.Column(db.String(20), unique=True)
	
	def __init__(self, descricao, nome):
		self.descricao = descricao
		self.nome = nome

	def __repr__(self):
		return "<Categoria %r>" % self.id_categoria

class Tipoestabelecimento(db.Model):
	__tablename__ = "tipoestabelecimentos"
	id_tipoestab = db.Column(db.Integer, primary_key = True, autoincrement=True)
	descricao = db.Column(db.String)
	nome = db.Column(db.String, unique=True)
	
	def __init__(self, descricao, nome):
		self.descricao = descricao

	def __repr__(self):
		return "<Tipoestabelecimento %r>" % self.descricao


class Tcontato(db.Model):
	__tablename__= "tcontatos"

	cod_tcontato = db.Column(db.Integer, primary_key = True, autoincrement=True)
	dsc_tcontato = db.Column(db.String(20), unique=True)
	
	def __init__(self, dsc_tcontato):
		self.dsc_tcontato = dsc_tcontato
		
	def __repr__(self):
		return "<Tcontato %r>" % self.dsc_tcontato




class Contato(db.Model):
	__tablename__ = "contatos"
	cod_contato = db.Column(db.Integer, primary_key = True, autoincrement=True)
	dsc_contato = db.Column(db.String(80), unique=True)

	def __init__(self, dsc_contato):
		self.dsc_contato = dsc_contato

	def __repr__(self):
		return "<Contato %r>" % self.dsc_contato


class Cidade(db.Model):
	__tablename__ = "cidades"

	cod_cidade = db.Column(db.Integer, primary_key = True, autoincrement=True)
	cidade = db.Column(db.String)
		
	def __init__(self, cidade):
		self.cidade = cidade


	def __repr__(self):
		return "<Cidade %r>" % self.cidade


class Bairro(db.Model):
	__tablename__ = "bairros"

	cod_bairro = db.Column(db.Integer, primary_key = True, autoincrement=True)
	nome_bairro = db.Column(db.String(20))

	
	def __init__(self, nome_bairro):
		self.nome_bairro = nome_bairro


	def __repr__(self):
		return "<Bairro %r>" % self.cod_bairro



class Endereco(db.Model):
	__tablename__ = "enderecos"

	cep = db.Column(db.Integer,  primary_key = True)
	logradouro = db.Column(db.String)
	

	def __init__(self, logradouro, cep):
		self.cep = cep
		self.logradouro = logradouro

		
	def __repr__(self):
		return "<Endereco %r>" % self.cep



db.create_all()